angular.module('myApp')

.controller('LoginCtrl', ['$scope', function($scope) {
    $scope.test = 'test';
}]);