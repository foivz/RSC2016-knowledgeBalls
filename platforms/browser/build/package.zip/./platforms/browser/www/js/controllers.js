angular.module('myApp')

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {
})
